import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MovieserviesService } from './movieservies.service';
import { Movie } from './movie.dto';

@Component({
  selector: 'app-movie-list',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './movie-list.component.html',
  styleUrl: './movie-list.component.css'
})
export class MovieListComponent {

  myform!: FormGroup;
  movielist:Movie[]=[];
  mobj:Movie={};
  constructor(private fb: FormBuilder,private mservice:MovieserviesService) {
    this.myform = this.fb.group({
      id: ["", [Validators.required]],
      mname: ["",Validators.required],
      mdate: ["",Validators.required],
      mcollection: ["",Validators.required],

    });
    this.showMovieList();
  }
  get id(){return this.myform.get('id')}
  get mname() { return this.myform.get('mname'); }
  get mdate() { return this.myform.get('mdate'); }
  get mcollection() { return this.myform.get('mcollection');}

  showMovieList(){
    this.mservice.getMovieList().subscribe(result=>{
      this.movielist=result;
      console.log(this.movielist);
    })
  }

  saveMovie(){
    this.mobj=this.myform.value;
    this.mservice.addMovie(this.mobj).subscribe(result=>{
      this.showMovieList();
    })
  }

  removeMovie(id: any){
    alert("in")
    this.mservice.deleteMovie(id).subscribe(result=>{
      this.showMovieList();
    })
  }
}
