import { TestBed } from '@angular/core/testing';

import { MovieserviesService } from './movieservies.service';

describe('MovieserviesService', () => {
  let service: MovieserviesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MovieserviesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
