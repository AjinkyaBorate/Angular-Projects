export class Movie{
    id?:string;
    mname?:string;
    mdate?:string;
    mcollection?:number;
}